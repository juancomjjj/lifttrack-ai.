# Gera HTML autônomo a partir dos mesmos componentes React (bibliotecas UMD locais).
# Uso: python scripts/make-demo.py caminho/react.js caminho/react-dom.js destino.html
import sys,re,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
react,dom,out=map(pathlib.Path,sys.argv[1:])
core=(root/'src/core.js').read_text().replace('export ','')
app=re.sub(r'^import .*?;\n','',(root/'src/app.js').read_text(),count=1).replace('export function makeApp','function makeApp')
css=(root/'src/style.css').read_text()
scripts='\n'.join([react.read_text(),dom.read_text(),core,app,"ReactDOM.render(React.createElement(makeApp(React),{demo:true}),document.getElementById('root'));"])
out.write_text('<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>LiftTrack | Demo local</title><style>'+css+'</style></head><body><div id="root"></div><script>'+scripts.replace('</script','<\\/script')+'</script></body></html>')
