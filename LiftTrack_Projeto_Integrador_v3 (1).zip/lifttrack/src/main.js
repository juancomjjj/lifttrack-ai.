import React from 'react';import {createRoot} from 'react-dom/client';import {makeApp} from './app.js';import './style.css';
const App=makeApp(React);createRoot(document.getElementById('root')).render(React.createElement(App,{demo:import.meta.env.VITE_LOCAL_DEMO==='true'}));
