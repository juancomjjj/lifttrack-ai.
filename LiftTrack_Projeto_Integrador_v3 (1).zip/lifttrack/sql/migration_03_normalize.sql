-- SOMENTE banco v2 com coluna plan JSONB. Faça backup antes. Execute inteiro.
BEGIN;
ALTER TABLE workout_plans ADD COLUMN title VARCHAR(80), ADD COLUMN minutes INT,
 ADD COLUMN intensity VARCHAR(12), ADD COLUMN recovery BOOLEAN;
UPDATE workout_plans SET title=plan->>'title', minutes=(plan->>'minutes')::int,
 intensity=plan->>'intensity', recovery=(plan->>'recovery')::boolean;
ALTER TABLE workout_plans ALTER COLUMN title SET NOT NULL, ALTER COLUMN minutes SET NOT NULL,
 ALTER COLUMN intensity SET NOT NULL, ALTER COLUMN recovery SET NOT NULL,
 ALTER COLUMN recovery SET DEFAULT FALSE,
 ADD CHECK(length(trim(title))>0), ADD CHECK(minutes IN (15,20,30,45,60)),
 ADD CHECK(intensity IN ('Leve','Moderado','Intenso')),
 ADD CHECK(NOT recovery OR (intensity='Leve' AND minutes<=20)), ADD UNIQUE(user_id,id);
CREATE TABLE IF NOT EXISTS workout_plan_items (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL,
 plan_id INT NOT NULL,
 exercise_id INT NOT NULL,
 position INT NOT NULL CHECK(position BETWEEN 1 AND 6),
 sets INT NOT NULL CHECK(sets BETWEEN 1 AND 4),
 reps INT NOT NULL CHECK(reps BETWEEN 5 AND 20),
 rest INT NOT NULL CHECK(rest IN (60,90,120,180)),
 FOREIGN KEY(user_id,plan_id) REFERENCES workout_plans(user_id,id) ON DELETE CASCADE,
 FOREIGN KEY(user_id,exercise_id) REFERENCES exercises(user_id,id),
 UNIQUE(plan_id,position), UNIQUE(plan_id,exercise_id)
);
-- Auxiliar operacional para limites globais; não é entidade de domínio.
CREATE TABLE IF NOT EXISTS service_limits (
 scope VARCHAR(32) PRIMARY KEY,
 window_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 used INT NOT NULL CHECK(used>=0)
);
INSERT INTO workout_plan_items(user_id,plan_id,exercise_id,position,sets,reps,rest)
SELECT p.user_id,p.id,(x.item->>'exerciseId')::int,x.ord::int,
 (x.item->>'sets')::int,(x.item->>'reps')::int,(x.item->>'rest')::int
FROM workout_plans p CROSS JOIN LATERAL jsonb_array_elements(p.plan->'items') WITH ORDINALITY AS x(item,ord);
DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM workout_plans p WHERE NOT EXISTS (SELECT 1 FROM workout_plan_items i WHERE i.plan_id=p.id))
 THEN RAISE EXCEPTION 'Ficha sem itens: revise os dados legados'; END IF;
END $$;
ALTER TABLE workout_plans DROP COLUMN plan;
COMMIT;
