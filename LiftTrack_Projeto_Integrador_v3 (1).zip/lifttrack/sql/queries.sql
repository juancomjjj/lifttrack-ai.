-- JOIN: histórico contendo nome, carga e equipamento do perfil fictício SQL.
SELECT r.workout_date,e.name,e.equipment,r.weight,r.sets,r.reps
FROM records r JOIN exercises e ON e.id=r.exercise_id AND e.user_id=r.user_id
JOIN users u ON u.id=r.user_id WHERE u.session_id='00000000-0000-4000-8000-000000000001'
ORDER BY r.workout_date DESC;
-- Agregação: volume por exercício nos últimos 30 dias.
SELECT e.name, SUM(r.weight*r.reps*r.sets) AS volume_kg, COUNT(DISTINCT r.workout_date) AS dias
FROM records r JOIN exercises e ON e.id=r.exercise_id AND e.user_id=r.user_id
JOIN users u ON u.id=r.user_id WHERE u.session_id='00000000-0000-4000-8000-000000000001' AND r.workout_date>=CURRENT_DATE-29
GROUP BY e.name ORDER BY volume_kg DESC;
-- Em banco de teste, execute ANTES, salve o plano, depois crie o índice e repita.
EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM records WHERE user_id=(SELECT id FROM users WHERE session_id='00000000-0000-4000-8000-000000000001') ORDER BY workout_date DESC;
CREATE INDEX IF NOT EXISTS idx_records_user_date ON records(user_id,workout_date DESC);
ANALYZE records;
EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM records WHERE user_id=(SELECT id FROM users WHERE session_id='00000000-0000-4000-8000-000000000001') ORDER BY workout_date DESC;

-- JOIN adicional: fichas normalizadas e respectivos exercícios (todos fictícios).
SELECT p.id, p.title, i.position, e.name, i.sets, i.reps, i.rest
FROM workout_plans p JOIN workout_plan_items i ON (i.user_id,i.plan_id)=(p.user_id,p.id)
JOIN exercises e ON (e.user_id,e.id)=(i.user_id,i.exercise_id)
ORDER BY p.id,i.position;
