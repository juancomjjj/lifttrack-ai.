-- Dados fictícios para auditoria SQL, independentes dos perfis da aplicação.
INSERT INTO users(session_id,name) VALUES ('00000000-0000-4000-8000-000000000001','Atleta fictício SQL') ON CONFLICT DO NOTHING;
INSERT INTO exercises(user_id,name,muscle,equipment,goal)
SELECT id,'Supino reto','Peito','Barra',40 FROM users WHERE session_id='00000000-0000-4000-8000-000000000001' ON CONFLICT DO NOTHING;
INSERT INTO records(user_id,exercise_id,workout_date,weight,sets,reps,rpe,side,note)
SELECT e.user_id,e.id,CURRENT_DATE-i,20+(10-i)*2.5,3,12,7,'Ambos','Seed SQL' FROM exercises e JOIN users u ON u.id=e.user_id CROSS JOIN generate_series(0,10) i WHERE u.session_id='00000000-0000-4000-8000-000000000001' AND NOT EXISTS(SELECT 1 FROM records r WHERE r.exercise_id=e.id AND r.workout_date=CURRENT_DATE-i);
