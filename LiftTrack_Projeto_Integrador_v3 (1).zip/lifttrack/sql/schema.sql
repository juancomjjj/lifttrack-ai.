-- Execute no SQL Editor do Neon. Todos os perfis são fictícios.
CREATE TABLE IF NOT EXISTS users (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 session_id UUID NOT NULL UNIQUE, name VARCHAR(100) NOT NULL DEFAULT 'Atleta fictício',
 ai_window TIMESTAMPTZ NOT NULL DEFAULT NOW(), ai_count INT NOT NULL DEFAULT 0 CHECK(ai_count>=0)
);
CREATE TABLE IF NOT EXISTS exercises (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name VARCHAR(100) NOT NULL, muscle VARCHAR(30) NOT NULL, equipment VARCHAR(80) NOT NULL,
 goal NUMERIC(8,2) NOT NULL DEFAULT 0 CHECK(goal BETWEEN 0 AND 1000),
 UNIQUE(user_id,name,equipment), UNIQUE(user_id,id)
);
CREATE TABLE IF NOT EXISTS records (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL, exercise_id INT NOT NULL,
 workout_date DATE NOT NULL, weight NUMERIC(8,2) NOT NULL CHECK(weight BETWEEN 0 AND 1000),
 sets INT NOT NULL CHECK(sets BETWEEN 1 AND 100), reps INT NOT NULL CHECK(reps BETWEEN 1 AND 500),
 rpe INT NOT NULL DEFAULT 0 CHECK(rpe BETWEEN 0 AND 10),
 side VARCHAR(12) NOT NULL CHECK(side IN ('Ambos','Esquerdo','Direito')),
 note VARCHAR(500) NOT NULL DEFAULT '',
 FOREIGN KEY (user_id,exercise_id) REFERENCES exercises(user_id,id) ON DELETE CASCADE
);
-- Fichas normalizadas: cabeçalho e itens com integridade por perfil.
CREATE TABLE IF NOT EXISTS workout_plans (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title VARCHAR(80) NOT NULL CHECK(length(trim(title))>0),
 minutes INT NOT NULL CHECK(minutes IN (15,20,30,45,60)),
 intensity VARCHAR(12) NOT NULL CHECK(intensity IN ('Leve','Moderado','Intenso')),
 recovery BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CHECK(NOT recovery OR (intensity='Leve' AND minutes<=20)),
 UNIQUE(user_id,id)
);
CREATE TABLE IF NOT EXISTS workout_plan_items (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL,
 plan_id INT NOT NULL,
 exercise_id INT NOT NULL,
 position INT NOT NULL CHECK(position BETWEEN 1 AND 6),
 sets INT NOT NULL CHECK(sets BETWEEN 1 AND 4),
 reps INT NOT NULL CHECK(reps BETWEEN 5 AND 20),
 rest INT NOT NULL CHECK(rest IN (60,90,120,180)),
 FOREIGN KEY(user_id,plan_id) REFERENCES workout_plans(user_id,id) ON DELETE CASCADE,
 FOREIGN KEY(user_id,exercise_id) REFERENCES exercises(user_id,id),
 UNIQUE(plan_id,position), UNIQUE(plan_id,exercise_id)
);
-- Auxiliar operacional para limites globais; não é entidade de domínio.
CREATE TABLE IF NOT EXISTS service_limits (
 scope VARCHAR(32) PRIMARY KEY,
 window_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 used INT NOT NULL CHECK(used>=0)
);
