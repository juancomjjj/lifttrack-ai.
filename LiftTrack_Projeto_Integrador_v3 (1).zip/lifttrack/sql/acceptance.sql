-- Executar em banco de teste após schema.sql. Nenhum dado deste teste é mantido.
BEGIN;
DO $$
DECLARE u1 int; u2 int; e1 int; e2 int; p1 int; n int;
BEGIN
 INSERT INTO users(session_id) VALUES('00000000-0000-4000-8000-000000000011') RETURNING id INTO u1;
 INSERT INTO users(session_id) VALUES('00000000-0000-4000-8000-000000000012') RETURNING id INTO u2;
 INSERT INTO exercises(user_id,name,muscle,equipment) VALUES(u1,'Teste A','Peito','Barra') RETURNING id INTO e1;
 INSERT INTO exercises(user_id,name,muscle,equipment) VALUES(u2,'Teste B','Peito','Barra') RETURNING id INTO e2;
 INSERT INTO workout_plans(user_id,title,minutes,intensity) VALUES(u1,'Teste de ficha',20,'Leve') RETURNING id INTO p1;
 INSERT INTO workout_plan_items(user_id,plan_id,exercise_id,position,sets,reps,rest) VALUES(u1,p1,e1,1,1,8,120);
 BEGIN
  INSERT INTO workout_plan_items(user_id,plan_id,exercise_id,position,sets,reps,rest) VALUES(u1,p1,e2,2,1,8,120);
  RAISE EXCEPTION 'Falha: FK aceitou outro perfil';
 EXCEPTION WHEN foreign_key_violation THEN RAISE NOTICE 'OK: FK impede exercício de outro perfil'; END;
 BEGIN
  INSERT INTO records(user_id,exercise_id,workout_date,weight,sets,reps,side) VALUES(u1,e1,CURRENT_DATE,-1,1,8,'Ambos');
  RAISE EXCEPTION 'Falha: carga negativa aceita';
 EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK: CHECK impede carga negativa'; END;
 INSERT INTO records(user_id,exercise_id,workout_date,weight,sets,reps,side) VALUES(u1,e1,CURRENT_DATE,20,1,12,'Ambos'),(u1,e1,CURRENT_DATE,25,1,8,'Ambos');
 SELECT count(*) INTO n FROM records WHERE user_id=u1; IF n<>2 THEN RAISE EXCEPTION 'Falha: séries'; END IF;
 DELETE FROM workout_plans WHERE id=p1 AND user_id=u1;
 SELECT count(*) INTO n FROM workout_plan_items WHERE plan_id=p1; IF n<>0 THEN RAISE EXCEPTION 'Falha: cascade'; END IF;
 RAISE NOTICE 'OK: duas séries independentes e exclusão em cascata';
END $$;
ROLLBACK;
