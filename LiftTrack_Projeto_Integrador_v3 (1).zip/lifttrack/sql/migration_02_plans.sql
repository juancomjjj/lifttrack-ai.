-- Executar também em instalações anteriores, após schema.sql.
CREATE TABLE IF NOT EXISTS workout_plans (
 id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 plan JSONB NOT NULL CHECK(jsonb_typeof(plan)='object'),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
