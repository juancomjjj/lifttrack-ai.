# Evidências reais ainda necessárias
E1 — print GitHub e contribuições individuais (não fabricar commits).
E2 — print cadastro, recarga e consulta do mesmo registro no Neon.
E3 — print JOIN e resultado do teste SQL; diagrama já fornecido.
E4 — print EXPLAIN antes/depois e interpretação da mudança real.
E5 — print resposta real Gemini sem credencial.
E6 — link Vercel, print mobile e loading/erro, saída do build.
Cada captura deve acompanhar o que foi feito, como e o que comprova. Os logs existentes documentam somente testes locais; não substituem as evidências acima.
