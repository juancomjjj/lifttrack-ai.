# Relatório técnico — LiftTrack AI v3
**Projeto Integrador — Desenvolvimento Web para IA + Banco de Dados**  
**Equipe:** [três nomes e contribuições reais]  
**Professor(es):** [preencher]  
**Entrega:** 04/12/2026

## 1. Introdução, problema e objetivo
Praticantes de musculação costumam registrar pesos em anotações dispersas. O LiftTrack centraliza planejamento, registro de cargas e interpretação da evolução. O público-alvo é praticantes de musculação iniciantes ou intermediários. A demonstração usa somente perfis fictícios.

## 2. Arquitetura e desenvolvimento
React/Vite cria a interface responsiva. O frontend chama funções Vercel por HTTP/JSON. O backend valida as entradas, usa SQL parametrizado para PostgreSQL/Neon e chama Gemini por HTTPS. As credenciais permanecem no servidor. O cookie HttpOnly identifica o perfil fictício; exclusões são limitadas ao próprio perfil. Não é autenticação de produção. O sistema inclui limites globais e por perfil. Veja README para reprodução.

## 3. Modelagem relacional
Cinco tabelas de domínio: users, exercises, records, workout_plans e workout_plan_items; service_limits é auxiliar operacional. Todas têm PK. A relação 1:N entre usuário e exercícios, exercício e registros, usuário e fichas, ficha e itens, exercício e itens garante vínculos coerentes. FKs compostas impedem itens de outro perfil. UNIQUE evita duplicidade de exercícios/posições em uma ficha; CHECK e NOT NULL limitam valores. A v3 substituiu JSONB persistido pela estrutura relacional de itens. Séries de pesos diferentes podem ser salvas individualmente com sets=1. Veja diagrama-banco.png e sql/schema.sql.

## 4. Consultas e índice
A consulta JOIN do histórico reúne registros e exercícios; a agregação calcula volume (carga × séries × repetições) e dias de treino. Outro JOIN recupera fichas e itens normalizados. O índice idx_records_user_date é justificável porque o histórico filtra por usuário e ordena por data. EXPLAIN ANALYZE BUFFERS antes/depois permite comparar a estratégia real, custos e buffers. Em tabelas pequenas, Seq Scan pode ser escolhido. Execute sql/seed.sql, sql/queries.sql e sql/acceptance.sql em banco de teste. **[Inserir planos, resultados, interpretação e capturas reais após execução.]**

## 5. Inteligência artificial
Quatro tarefas: extrair registros de texto/foto, interpretar histórico, extrair preferências explícitas e sugerir fichas com catálogo e preferências. A resposta é validada; registros e fichas só são gravados após revisão. A IA não prescreve cargas, não autoriza retorno após doença nem substitui profissional. O retorno tem controles de sintomas e liberação informada em cenário fictício. A demo aplica regras locais e não é IA real. **[Inserir entrada/saída de chamada real e legenda E5.]**

## 6. Testes e evidências
12 testes unitários passaram; ver docs/evidencias/testes-unitarios.txt. Verificação sintática dos JS passou. No Chromium foi testado o conteúdo HTML em memória, com geração, salvamento local em estado, abertura de ficha e registros de duas séries. Navegação direta bloqueada; não comprovou F5. npm install falhou por DNS EAI_AGAIN. Build Vite, SQL, Neon, Gemini e Vercel ainda não verificados. As capturas locais não são evidência de integração externa. **[Completar E1–E6 com evidências reais, URLs, nomes e resultados.]**

## 7. Conclusão
A implementação integra a interface, lógica de negócio, API e scripts de banco e IA. A normalização melhora a integridade e a consulta das fichas; a separação do backend protege credenciais. A conclusão sobre funcionamento ponta a ponta depende da execução dos serviços externos e da defesa do trio. **[Complementar aprendizado real de cada integrante depois da validação.]**

## Referência principal
Edital Projeto Integrador — Front-end + Banco de Dados + IA, fornecido pelos docentes. Registrar referências técnicas consultadas pela equipe e datas de acesso no relatório final.
