# Checklist de validação e evidências

Não marque itens apenas porque o código foi escrito; execute a verificação real.

| Evidência | Como comprovar | Estado ao entregar este pacote |
|---|---|---|
| E1 Projeto e histórico | GitHub com README, pastas, commits individuais reais | Pendente de repositório e equipe |
| E2 Persistência | GET, cadastro de 43 kg na interface, F5, consulta SQL do próprio registro | Código pronto; teste PostgreSQL pendente |
| E3 Integridade | Diagrama, PK/FK, JOIN real, tentativa de exercício inválido | SQL fornecido; execução pendente |
| E4 Índice | EXPLAIN antes e depois de CREATE INDEX; comparar plano | Script fornecido; planos pendentes |
| E5 IA | Entrada de anotação fictícia e resultado real do Gemini; confirmar e salvar | Integração escrita; chave/config/teste pendentes |
| E6 Produção e qualidade | URL Vercel, build, mobile, loading e erro real | Demo local testada parcialmente; produção pendente |

## Cenários de aceite (produção)

- [ ] Abrir Vercel, conferir perfil e catálogo; GET /api/data retorna 200.
- [ ] Registrar supino 43 kg, 3×12. Recarregar a página e verificar o registro no banco e na interface.
- [ ] Editar para 45 kg; consultar histórico; excluir com confirmação; recarregar de novo.
- [ ] Tentar carga negativa, data inválida ou ID de outro perfil; API deve rejeitar. Abrir janela anônima e verificar isolamento (perfil novo).
- [ ] Importar anotação em texto com IA; revisar o resultado antes de salvar; provar alteração no banco. Testar também uma foto fictícia e pergunta contextual.
- [ ] Desabilitar IA/usar quota indisponível em ambiente de teste; mostrar mensagem compreensível; nunca simular resposta.
- [ ] Consultar gráfico, metas, mapa muscular e comparação com dados de teste suficientes.
- [ ] Testar calculadora: 70 kg com barra 20 kg = 25 kg por lado; 71 kg deve avisar inexatidão.
- [ ] Testar teclado, foco, celular, Safari/Chrome/Edge, permissão de voz/câmera e PDF.
- [ ] Executar npm test e npm run build; guardar saída.
- [ ] Inserir prints E1–E6 e legendas: o que foi feito, como e o que comprovam.

## Roteiro de defesa — 8 a 10 min

0–1 min: problema e proposta. 1–3:30: cadastrar exercício e registro, editar, F5 e histórico. 3:30–5:00: IA real, contexto, validação e revisão. 5–6:30: SQL, PK/FKs, JOIN, agregação e EXPLAIN. 6:30–8:00: GitHub, Vercel, variáveis e evidências. 8–10:00: perguntas. Todos falam e explicam as próprias contribuições.

## Divisão sugerida

Integrante 1: React/UX e testes de interface. Integrante 2: PostgreSQL, backend e auditoria SQL. Integrante 3: IA, deploy e testes integrados. Todos: código, revisão, documentação e apresentação. Substituam por nomes e atividades de fato realizadas.

## Atualização v2
`npm test`: 9 testes unitários passaram (incluindo bloqueio por sintomas, exigência de liberação, limites do retorno e validação de catálogo). `node --check` nos arquivos JS modificados passou. A navegação do Chromium para arquivo local/localhost foi bloqueada pela política do ambiente, portanto a nova ficha ainda requer teste manual completo do navegador. As capturas de tela anteriores ilustram a v1. PostgreSQL/Neon, Gemini e deploy ainda exigem configuração e verificação real.

## Atualização v3 (substitui estados técnicos v1/v2 acima)
- 12 testes unitários passaram; sintaxe dos JS verificada. Logs em `evidencias/`.
- Chromium em memória: preferências → ficha → salvar → iniciar → registrar séries individuais. Sem erros JS nesse fluxo. Navegação direta bloqueada; F5 não verificado.
- `npm install` tentado e bloqueado por DNS. Build pendente.
- Banco normalizado em cinco entidades + tabela operacional. Migração v2→v3, JOIN adicional e teste SQL preparados, ainda não executados.
- Limites globais implementados; validar em banco de teste antes de produção.
- E1 GitHub, E2 persistência real, E3 SQL real, E4 EXPLAIN, E5 Gemini e E6 Vercel ainda pendentes. Não usar imagens demo como prova dessas etapas.
